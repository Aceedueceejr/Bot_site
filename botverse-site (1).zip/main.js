
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "YOUR_APP_ID"
};
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  auth.signInWithEmailAndPassword(email, password)
    .then(() => { showDashboard(); })
    .catch(err => {
      document.getElementById("authStatus").innerText = err.message;
    });
}

function signup() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  auth.createUserWithEmailAndPassword(email, password)
    .then(() => { showDashboard(); })
    .catch(err => {
      document.getElementById("authStatus").innerText = err.message;
    });
}

function logout() {
  auth.signOut().then(() => {
    document.getElementById("dashboard").classList.add("hidden");
    document.getElementById("auth").classList.remove("hidden");
  });
}

function showDashboard() {
  document.getElementById("auth").classList.add("hidden");
  document.getElementById("dashboard").classList.remove("hidden");
}

auth.onAuthStateChanged(user => {
  if (user) showDashboard();
});
